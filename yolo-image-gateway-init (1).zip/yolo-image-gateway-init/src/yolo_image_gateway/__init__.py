"""YOLO Image Gateway package."""
