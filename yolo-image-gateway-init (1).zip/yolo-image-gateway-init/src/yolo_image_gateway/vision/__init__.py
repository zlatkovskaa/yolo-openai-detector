"""Vision modules."""
