"""Placeholder for src/yolo_image_gateway/vision/schemas.py. Implement via docs/work-orders/001-api-skeleton.md."""
