"""Placeholder for src/yolo_image_gateway/openai_compat/errors.py. Implement via docs/work-orders/001-api-skeleton.md."""
