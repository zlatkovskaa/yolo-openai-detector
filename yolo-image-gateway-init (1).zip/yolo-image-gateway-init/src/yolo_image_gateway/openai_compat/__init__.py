"""OpenAI compatibility helpers."""
