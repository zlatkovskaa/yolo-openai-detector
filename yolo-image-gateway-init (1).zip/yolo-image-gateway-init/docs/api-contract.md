# API Contract

## Base URL

Local default:

```text
http://localhost:8000
```

API compatibility namespace:

```text
/v1
```

## Authentication

Protected endpoints require:

```http
Authorization: Bearer <YOLO_GATEWAY_API_KEY>
```

The fixed key is configured by environment variable.

## Endpoints

### `GET /healthz`

Operational health check.

Authentication: not required, unless the implementation owner chooses to require it.

Response:

```json
{
  "status": "ok"
}
```

The endpoint must not reveal secrets, model paths, host information, or detailed environment data.

---

### `GET /v1/models`

Model discovery.

Authentication: required.

Response:

```json
{
  "object": "list",
  "data": [
    {
      "id": "yolo-cpu-detector",
      "object": "model",
      "created": 1782720000,
      "owned_by": "local"
    }
  ]
}
```

The exact `created` value may be a fixed timestamp or service startup timestamp. Keep it stable enough for tests.

---

### `POST /v1/chat/completions`

Single-image object detection endpoint.

Authentication: required.

Request:

```json
{
  "model": "yolo-cpu-detector",
  "messages": [
    {
      "role": "user",
      "content": [
        {
          "type": "text",
          "text": "Detect objects in this image."
        },
        {
          "type": "image_url",
          "image_url": {
            "url": "data:image/jpeg;base64,..."
          }
        }
      ]
    }
  ]
}
```

Supported MIME types:

- `image/jpeg`
- `image/png`
- `image/webp`

Unsupported:

- external URLs
- file IDs
- file upload objects
- multiple images
- video
- segmentation requests
- tracking requests

Success response:

```json
{
  "id": "chatcmpl-local-...",
  "object": "chat.completion",
  "created": 1782720000,
  "model": "yolo-cpu-detector",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "{\"detections\":[{\"label\":\"person\",\"class_id\":0,\"confidence\":0.91,\"box\":{\"x1\":120.0,\"y1\":80.0,\"x2\":340.0,\"y2\":500.0}}],\"image\":{\"width\":640,\"height\":480},\"runtime\":{\"backend\":\"ultralytics\",\"device\":\"cpu\"}}"
      },
      "finish_reason": "stop"
    }
  ]
}
```

## Detection JSON schema inside `message.content`

`message.content` is a string containing JSON.

Decoded content:

```json
{
  "detections": [
    {
      "label": "person",
      "class_id": 0,
      "confidence": 0.91,
      "box": {
        "x1": 120.0,
        "y1": 80.0,
        "x2": 340.0,
        "y2": 500.0
      }
    }
  ],
  "image": {
    "width": 640,
    "height": 480
  },
  "runtime": {
    "backend": "ultralytics",
    "device": "cpu"
  }
}
```

## Error shape

Use a stable OpenAI-like error object where practical:

```json
{
  "error": {
    "message": "Exactly one image data URL is required.",
    "type": "invalid_request_error",
    "param": "messages",
    "code": "invalid_image_count"
  }
}
```

Recommended HTTP status codes:

| Case | Status |
|---|---:|
| Missing/wrong API key | 401 |
| Missing/invalid request fields | 400 |
| Unsupported model | 400 |
| Unsupported endpoint | 404 |
| Internal detector failure | 500 |
| Image too large | 413 |
