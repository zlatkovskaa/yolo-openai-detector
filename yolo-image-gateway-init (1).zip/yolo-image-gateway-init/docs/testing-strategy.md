# Testing Strategy

## Test philosophy

The gateway must be testable without GPU, without large model downloads, and without external network access.

The first implementation should mock the detector for API contract tests. Real YOLO integration tests can be added separately and marked clearly.

## Required test groups

| Group | Purpose |
|---|---|
| Auth tests | Verify fixed bearer key enforcement. |
| Model endpoint tests | Verify `/v1/models` shape. |
| Request validation tests | Verify rejected inputs. |
| Image parser tests | Verify data URL parsing and base64 decoding. |
| Chat completion tests | Verify OpenAI-like response shape. |
| Detector adapter tests | Verify detector output normalization. |

## Required MVP tests

- `/healthz` returns `{"status": "ok"}`.
- missing API key returns 401.
- malformed auth header returns 401.
- wrong API key returns 401.
- correct API key returns 200.
- `/v1/models` returns `yolo-cpu-detector`.
- no image returns 400.
- multiple images returns 400.
- HTTP image URL returns 400.
- file URL returns 400.
- invalid base64 returns 400.
- unsupported MIME type returns 400.
- oversized decoded image returns 413.
- valid base64 image reaches mocked detector.
- mocked detector output appears as JSON string in `choices[0].message.content`.

## Test fixtures

Use tiny generated or committed sample images under:

```text
tests/fixtures/images/
```

Keep fixtures small.

## Test reporting rule

A skipped test is not a passing test.

Reports must distinguish:

- passed
- failed
- skipped
- not run
- blocked by environment
