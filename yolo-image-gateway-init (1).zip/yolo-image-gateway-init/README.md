# YOLO Image Gateway

CPU-first YOLO single-image object detection through an OpenAI-compatible API style.

This repository is initialized as a governed project scaffold. The first implementation must follow `AGENTS.md` and `CLAUDE.md`.

## Mission

Build a local HTTP gateway that accepts a single base64 image attached in an OpenAI-style `/v1/chat/completions` request, runs YOLO object detection on CPU, and returns detections in an OpenAI-like chat completion response.

## Current status

Repository initialization only.

The project currently contains:

- project constitution
- documentation
- API contract
- security rules
- testing strategy
- first implementation work order
- package/source/test folder skeleton

Implementation code is intentionally not included yet.

## MVP scope

| Capability | Status |
|---|---:|
| CPU-only operation | Required |
| Fixed bearer API key | Required |
| `GET /healthz` | Required |
| `GET /v1/models` | Required |
| `POST /v1/chat/completions` | Required |
| One image per request | Required |
| Base64 data URL image input | Required |
| YOLO object detection | Required |
| Tracking | Not supported |
| Video | Not supported |
| Segmentation | Not supported |
| Background jobs | Not supported |
| Database | Not supported |
| External image URLs | Not supported |
| OpenAI forwarding | Not supported |

## Intended API

### Health

```http
GET /healthz
```

Expected response:

```json
{
  "status": "ok"
}
```

### Models

```http
GET /v1/models
Authorization: Bearer <YOLO_GATEWAY_API_KEY>
```

Expected response shape:

```json
{
  "object": "list",
  "data": [
    {
      "id": "yolo-cpu-detector",
      "object": "model",
      "created": 1782720000,
      "owned_by": "local"
    }
  ]
}
```

### Chat completions detection request

```http
POST /v1/chat/completions
Authorization: Bearer <YOLO_GATEWAY_API_KEY>
Content-Type: application/json
```

```json
{
  "model": "yolo-cpu-detector",
  "messages": [
    {
      "role": "user",
      "content": [
        {
          "type": "text",
          "text": "Detect objects in this image."
        },
        {
          "type": "image_url",
          "image_url": {
            "url": "data:image/jpeg;base64,..."
          }
        }
      ]
    }
  ]
}
```

Expected response shape:

```json
{
  "id": "chatcmpl-local-...",
  "object": "chat.completion",
  "created": 1782720000,
  "model": "yolo-cpu-detector",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "{\"detections\":[],\"image\":{\"width\":640,\"height\":480}}"
      },
      "finish_reason": "stop"
    }
  ]
}
```

`message.content` is intentionally a JSON string for OpenAI client compatibility.

## Setup expectation

The first implementation should use Python 3.11+.

Planned stack:

- FastAPI
- Pydantic
- Uvicorn
- Pillow and/or OpenCV
- Ultralytics YOLO
- pytest
- ruff

## Environment variables

Copy `.env.example` to `.env` for local development.

```bash
cp .env.example .env
```

Required:

```bash
YOLO_GATEWAY_API_KEY=replace-with-local-development-key
```

## First implementation task

Use:

```text
docs/work-orders/001-api-skeleton.md
```

That work order intentionally starts with API/auth/schema/image-input behavior and mocked detector tests before real YOLO integration.

## Governance

Agents must read:

1. `AGENTS.md`
2. `CLAUDE.md`
3. `docs/architecture.md`
4. `docs/api-contract.md`
5. `docs/work-orders/001-api-skeleton.md`

Do not implement features outside the approved scope.

## License

No license has been selected in this scaffold. Add a license only after the project owner chooses one.
